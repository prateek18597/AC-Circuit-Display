#ifndef START_H
#define START_H
#include "Component.h"
#include "Source.h"
#include <iostream>
#include <fstream>
using namespace std;
#include <vector>

extern Source sour[1000];
extern int s_index;
extern Component comp[1000];
extern int c_index;
ofstream ofile;

void html()
{   
    ofile<<"<html>\n";
    ofile<<"<head><title>AC Circuit Solver</title>\n";
    ofile<<"<script type=\"text/javascript\" src=\"svg-pan-zoom.js\">\n";
    
    ofile<<"</script>\n";
    ofile<<"<script type=\"text/javascript\" src=\"script.js\">\n";
    ofile<<"</script>\n";
    //ofile<<"<script type=\"text/javascript\" src=\"script1.js\">\n";
    //ofile<<"</script>\n";
    
    ofile<<"</head><body>\n";
    ofile<<"<style>\n";
    ofile<<"body{\n";
    ofile<<"background-color: #93B874;\n";
    ofile<<"}\n";
    ofile<<"</style>\n";
}

void close()
{
  ofile<<"</body>\n";
  ofile<<"</html>\n";

}

void header(int numnets) {
 

// ofile<<"<svg height=\""<<2000<<"\" width=\""<<2000<<"\">"<<endl;
ofile<<"<div id=\"container\" style=\"width: 1200px; height: 650px;\">\n";
ofile<<"<svg id=\"circuit\" xmlns=\"http://www.w3.org/2000/svg\"";
ofile<<"style=\"overflow: hidden; display: inline; width: inherit;";
ofile<<"min-width: inherit; max-width: inherit; height: inherit;";
ofile<<"min-height: inherit; max-height: inherit; \" version=\"1.1\"";
ofile<<"xmlns:xlink=\"http://www.w3.org/1999/xlink\"";
ofile<<"xmlns:ev=\"http://www.w3.org/2001/xml-events\">\n";
 // height corresponds to vertical and width is horizontal

}
// Epilog for the SVG image


void footer() {
  ofile << "</svg>\n</div>" << endl;
  ofile<<"<div id=\"selenium-highlight\"></div>\n";
}

// Generation of the two segments

void line(int x,int y,int length,char c,int color)
{ 
  if(color==1){   
   
   if(c=='h')    
   ofile<<"<line x1=\""<<x<<"\" "<<"y1=\""<<y<<"\" "<<"x2=\""<<x+length<<"\" "<<"y2=\""<<y<<"\" "<<"style=\"stroke:rgb(0,0,0);stroke-width:2\" />"<<endl;
   else
   ofile<<"<line x1=\""<<x<<"\" "<<"y1=\""<<y<<"\" "<<"x2=\""<<x<<"\" "<<"y2=\""<<y+length<<"\" "<<"style=\"stroke:rgb(0,0,0);stroke-width:2\" />"<<endl;     
  
  }
  else
  {
   
   if(c=='h')    
   ofile<<"<line x1=\""<<x<<"\" "<<"y1=\""<<y<<"\" "<<"x2=\""<<x+length<<"\" "<<"y2=\""<<y<<"\" "<<"style=\"stroke:rgb(0,0,0);stroke-width:2\" />"<<endl;
   else
   ofile<<"<line x1=\""<<x<<"\" "<<"y1=\""<<y<<"\" "<<"x2=\""<<x<<"\" "<<"y2=\""<<y+length<<"\" "<<"style=\"stroke:rgb(0,0,0);stroke-width:2\" />"<<endl;
  
  } 

}

void resistor(int x, int y,float nu,int val,string id) {
  
    // ofile<<"div onclick=\"\""
    ofile<<"<path id=\""<<id<<"\" d=\"M"<<x<<" "<<y<<" L"<<x+5<<" "<<y+10<<" L"<<x+10<<" "<<y<<" L"<<x+15<<" "<<y+10<<" L"<<x+20<<" "<<y<<" L"<<x+25<<" "<<y+10<<" L"<<x+30<<" "<<y<<"\" stroke=\"black\" fill=\"none\" stroke-width=\"3\"/> "<<endl;
   // ofile<<"<text x=\""<<x+10<<"\" y=\""<<y-4<<"\" fill=\"black\">r"<<nu<<"="<<val<<"Ohm </text>";
}

void capc(int x,int y,string id){
  ofile<<"<g id=\""<<id<<"\" stroke=\"black\">\n";
  ofile<<"<line  x1=\""<<x<<"\" "<<"y1=\""<<y<<"\" "<<"x2=\""<<x+7.5<<"\" "<<"y2=\""<<y<<"\" "<<"style=\"stroke-width:2\" />"<<endl;
  ofile<<"<line  x1=\""<<x+7.5<<"\" "<<"y1=\""<<y-20<<"\" "<<"x2=\""<<x+7.5<<"\" "<<"y2=\""<<y+20<<"\" "<<"style=\"stroke-width:2\" />"<<endl;
  ofile<<"<line  x1=\""<<x+17.5<<"\" "<<"y1=\""<<y-20<<"\" "<<"x2=\""<<x+17.5<<"\" "<<"y2=\""<<y+20<<"\" "<<"style=\"stroke-width:2\" />"<<endl;
  ofile<<"<line  x1=\""<<x+17.5<<"\" "<<"y1=\""<<y<<"\" "<<"x2=\""<<x+25<<"\" "<<"y2=\""<<y<<"\" "<<"style=\"stroke-width:2\"  />"<<endl;
  ofile<<"</g>\n";
}


void Indc(int x,int y,string id){

  ofile<<"<g id=\""<<id<<"\" stroke=\"black\">\n";
  ofile<<"<path class=\""<<id<<"\" d=\"M"<<x<<","<<y<<" a0.5,1 0 0,0 10,0\" fill=\"none\"  stroke-width=\"3\" onclick=\""<<id<<"()\" />" ;
  ofile<<"<path class=\""<<id<<"\" d=\"M"<<x+10<<","<<y<<" a0.5,1 0 0,0 10,0\" fill=\"none\"  stroke-width=\"3\" onclick=\""<<id<<"()\" />" ;
  ofile<<"<path class=\""<<id<<"\" d=\"M"<<x+20<<","<<y<<" a0.5,1 0 0,0 10,0\" fill=\"none\"  stroke-width=\"3\" onclick=\""<<id<<"()\" />" ;
  ofile<<"<path class=\""<<id<<"\" d=\"M"<<x+30<<","<<y<<" a0.5,1 0 0,0 10,0\" fill=\"none\"  stroke-width=\"3\" onclick=\""<<id<<"()\" />" ;
  ofile<<"</g>\n";
}


void Volt(int x,int y,bool side,string id)
{
  //ofile<<"<text x=\""<<x-1<<"\" y=\""<<y-2<<"\" "<<" fill=\"red\">+"<<"</text>"<<endl;
  ofile<<"<g id=\""<<id<<"\" stroke=\"black\">\n";
  ofile<<"<circle cx=\""<<x<<"\"  cy=\""<<y<<"\" r=\"20\" "<<" stroke-width=\"3\" fill=\"none\"/>";
  ofile<<"<text x=\""<<x-8<<"\" y=\""<<y+5<<"\" "<<" font-size=\"20\" fill=\"black\">~"<<"</text>"<<endl;
  if(side==true)
  {
    ofile<<"<text x=\""<<x-35<<"\" y=\""<<y-3<<"\" "<<" font-size=\"20\" fill=\"black\">+"<<"</text>"<<endl;
    ofile<<"<text x=\""<<x+20<<"\" y=\""<<y-1<<"\" "<<" font-size=\"35\" fill=\"black\">-"<<"</text>"<<endl;
  } 
  else
  {

    ofile<<"<text x=\""<<x-35<<"\" y=\""<<y-1<<"\" "<<" font-size=\"35\" fill=\"black\">-"<<"</text>"<<endl;
    ofile<<"<text x=\""<<x+35<<"\" y=\""<<y-3<<"\" "<<" font-size=\"20\" fill=\"black\">+"<<"</text>"<<endl;

  }
  ofile<<"</g>\n";
}




void Curr(int x,int y,bool side,string id)
{
  ofile<<"<g id=\""<<id<<"\" stroke=\"black\">\n";
  ofile<<"<rect x=\""<<x<<"\" y=\""<<y-10<<"\" width=\"20\" height=\"20\" style=\"fill:none;stroke-width:2;\"/>";

  if(side==true)
  { 
    ofile<<"<text x=\""<<x-15<<"\" y=\""<<y<<"\" "<<" font-size=\"20\" fill=\"black\">+"<<"</text>"<<endl;
    ofile<<"<text x=\""<<x+23<<"\" y=\""<<y<<"\" "<<" font-size=\"30\" fill=\"black\">-"<<"</text>"<<endl;
  } 
  else
  { 
    ofile<<"<text x=\""<<x-15<<"\" y=\""<<y<<"\" "<<" font-size=\"30\" fill=\"black\">-"<<"</text>"<<endl;
    ofile<<"<text x=\""<<x+23<<"\" y=\""<<y<<"\" "<<" font-size=\"20\" fill=\"black\">+"<<"</text>"<<endl;
  }
  ofile<<"</g>\n";
}











void DrawCurr(int net1,int net2,int offset,string id)
{
  int diff=abs(net1-net2);

  float l1=(diff-20)/2 ;

  int x=min(net1,net2);

   bool side;

  if(x==net1)
  side=true;  
  else
  side=false;

  line(x,250+offset,l1,'h',1);
  Curr(x+l1,250+offset,side,id);
  line(x+l1+20,250+offset,l1,'h',1);

  line(net1,250,offset,'v',0);
  line(net2,250,offset,'v',0); 

}


void DrawVolt(int net1,int net2,int offset,string id)
{ 
  
  int diff=abs(net2-net1);

  float l1=(diff-40)/2 ;

  int x=min(net1,net2);

  bool side;
  
  if(x==net1)
  side=true;  
  else
  side=false;

  line(x,250+offset,l1,'h',1);
  Volt(x+l1+20,250+offset,side,id);
  line(x+l1+40,250+offset,l1,'h',1);

  line(net1,250,offset,'v',0);
  line(net2,250,offset,'v',0);  

}



void drawRes(int net1,int net2,int offset,int n,float val,char* c)
{
    int diff=abs(net2-net1);

    
    float l1=(diff-30)/2 ;

    int x=min(net1,net2);
      
    line(x,250+offset,l1,'h',1);
    string idrr="R"+to_string(n);
    // ofile<<"<div onclick=\"R"<<n<<"()\">"<<endl;
    resistor(x+l1,250+offset,n,val,idrr);
    // ofile<<"</div>"<<endl;
    line(x+l1+30,250+offset,l1,'h',1);

   ofile<<"<text x=\""<<x+l1+10<<"\" y=\""<<246+offset<<"\" fill=\"black\">R"<<n<<"="<<val<<"Ohm </text>";
   line(net1,250,offset,'v',0);
   line(net2,250,offset,'v',0);
    
}
  

void drawCap(int net1,int net2,int offset,int n,float val)
{
  int diff=abs(net2-net1);

  float l1=(diff-22)/2 ;

  int x=min(net1,net2);
string idrr="C"+to_string(n);
    line(x,250+offset,l1,'h',1);
    // ofile<<"<div onclick=\"C"<<n<<"()\">"<<endl;
    capc(x+l1,250+offset,idrr);
    // ofile<<"</div>"<<endl;
    line(x+l1+22,250+offset,l1,'h',1);
  
    ofile<<"<text x=\""<<x+l1+20<<"\" y=\""<<246+offset<<"\" fill=\"black\">C"<<n<<"="<<val<<"F</text>";

    line(net1,250,offset,'v',0);
    line(net2,250,offset,'v',0); 

}

void drawInd(int net1,int net2,int offset,int n,float val)
{

  int diff=abs(net2-net1);

  float l1=(diff-40)/2 ;

  int x=min(net1,net2);
  line(x,250+offset,l1,'h',1);
  string idrr="L"+to_string(n);
    // ofile<<"<div onclick=\"L"<<n<<"()\">"<<endl;
    Indc(x+l1,250+offset,idrr);
    // ofile<<"</div>"<<endl;
    line(x+l1+40,250+offset,l1,'h',1);

  ofile<<"<text x=\""<<x+l1+20<<"\" y=\""<<246+offset<<"\" fill=\"black\">L"<<n<<"="<<val<<"F</text>";

   line(net1,250,offset,'v',0);
   line(net2,250,offset,'v',0); 


}

void genmaim(string output) {
  unsigned x, y;
  
  bool N[1000];

    
  ofile.open(output);
  html();

  for(int i=0;i<1000;i++)
  N[i]=false; 

  
  
 int netval[1000];//={-1};
  int netvarnum[1000];//={0};
  int xo=0;
std::vector<int> enunet;

  for(int i=0;i<1000;i++)
  netval[i]=-1; 

  

  int num=c_index;
  int scount=s_index;

  int number[1000][1000];
  
  for(int i=0;i<1000;i++)
  {
  	for(int j=0;j<1000;j++)
  	number[i][j]=0;	

  }



  int s=10;

  for(int i=0;i<num;i++)
  {
  	int a = comp[i].getInitialNet();
  	int b = comp[i].getFinalNet();

  	
  	if(N[a]==false)
  	{	
  		netval[a]=s;
  		N[a]=true;
  		s+=300;

  	}	

  	if(N[b]==false)
  	{
  		netval[b]=s;
  		N[b]=true;
  		s+=300;

  	}	


  }
	
  int numnets=0;

  for(int i=0;i<1000;i++)
  {
    if(N[i]==true)
    numnets++;  

  }
  

  header(numnets);

 /* for(int i=0;i<1000;i++)
  {
    if(N[i]==true)
    {
      if(i!=0)
      ofile<<"<text x=\""<<netval[i]<<"\" y=\"248\" "<<" fill=\"black\">net"<<i-1<<"</text>"<<endl; 
      else
      ofile<<"<text x=\""<<netval[i]<<"\" y=\"248\" "<<" fill=\"black\">0"<<"</text>"<<endl;  

      ofile<<"<text x=\""<<netval[i]-10<<"\" y=\"250\" "<<" font-size=\"60\" fill=\"blue\">."<<"</text>"<<endl;
    }  

  }
  */

  
  
  int offset=80;
  for(int i=0;i<num;i++)
  { 
    int a = comp[i].getInitialNet();
    int b = comp[i].getFinalNet();

    char* c=comp[i].getStrValue();
    cout<<comp[i].getStrValue();
    
    int in=comp[i].getNum();
    float val =comp[i].getVal();  
    if( abs(netval[a] - netval[b]) == 300  &&  number[a][b]==0 ){

    if(comp[i].getType() == 'R')
    drawRes(netval[a],netval[b],0,in,val,c);
    else if(comp[i].getType() == 'C')
    drawCap(netval[a],netval[b],0,in,val);  
    else if(comp[i].getType() == 'L')
    drawInd(netval[a],netval[b],0,in,val);

  }
  else{

  if(comp[i].getType() == 'R')
  drawRes(netval[a],netval[b],offset,in,val,c);
  else if(comp[i].getType() == 'C')
  drawCap(netval[a],netval[b],offset,in,val); 
  else if(comp[i].getType() == 'L')
  drawInd(netval[a],netval[b],offset,in,val);
  offset+= 80;
  
  }

  number[a][b]++;
  number[b][a]++;


  }

  for(int i=0;i<scount;i++)
  {
        int a = sour[i].getInitialNet();
        int b = sour[i].getFinalNet();

        
        if(N[a]==false)
        { 
          netval[a]=s;
          N[a]=true;
          s+=300;
        } 

        if(N[b]==false)
        {
          netval[b]=s;
          N[b]=true;
          s+=300;
        } 
  }


       for(int i=0;i<1000;i++){
       
       if(N[i]==true){ 
       netvarnum[i]=xo;
       enunet.push_back(i);
       xo++;
       }
     }
  for(int i=0;i<1000;i++)
  {
    if(N[i]==true)
    {
      if(i!=0)
      ofile<<"<text x=\""<<netval[i]<<"\" y=\"248\" "<<" fill=\"black\">net"<<i-1<<"</text>"<<endl; 
      else
      ofile<<"<text x=\""<<netval[i]<<"\" y=\"248\" "<<" fill=\"black\">0"<<"</text>"<<endl;  

      ofile<<"<text x=\""<<netval[i]-10<<"\" y=\"250\" "<<" font-size=\"60\" fill=\"blue\">."<<"</text>"<<endl;
    }  

  }

  int sourcevarnum[scount];

  int viset=-80;
  for(int i=0;i<scount;i++)
  {
      int a = sour[i].getInitialNet();
      int b = sour[i].getFinalNet();

     sourcevarnum[i]=0;
      
     float dco=sour[i].getDCO();
     float amp=sour[i].getAmpli();
     float delay=sour[i].getDelay();
     float freq=sour[i].getFreq();  
     float damp=sour[i].getDamp();   

      int numberV=sour[i].getNum();


      if( sour[i].getType() == 'V' )
      { DrawVolt(netval[a],netval[b],viset,"V"+to_string(numberV));  
        sourcevarnum[i]=xo;
        xo++;
      }  
      else if(sour[i].getType() == 'I')
      DrawCurr(netval[a],netval[b],viset,"I"+to_string(numberV));
      
      float d= abs(netval[a]-netval[b]);
      d=d/2;
      d=min(netval[a],netval[b]) + d;
      ofile<<"<text x=\""<<d-2<<"\" y=\""<<225+viset<<"\" fill=\"black\"> SINE("<<dco<<" "<<amp<<" "<<freq<<"Hz "<<delay<<" "<<damp<<") </text>";
      ofile<<"<text x=\""<<d-30<<"\"y=\""<<225+viset<<"\" fill=\"black\">"<<sour[i].getType()<<numberV<<"</text>\n";
      viset-= 80;
  
    //SINE ( < DCOf f set> < Amplitude> < F requency> < Delay> < DampingF actor>)

      number[a][b]++;
      number[b][a]++;

  }	




  
  footer();
  close();
  ofile.close();

}


#endif

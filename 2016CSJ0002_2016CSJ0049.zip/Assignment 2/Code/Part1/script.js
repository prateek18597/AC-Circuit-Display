      window.onload = function() {
        window.circuit = svgPanZoom('#circuit', {
          zoomEnabled: true,
          controlIconsEnabled: true,
          fit: true,
          center: true,
        });
      };
